package LexicalAnalyzer.States;

import Diccionary.Diccionary;
import LexicalAnalyzer.States.Interfaces.BasicAcceptanceState;

public class S25 extends BasicAcceptanceState {
    public S25(Diccionary diccionary, String buffer) {
        super(diccionary, buffer);
        this.token = "token_cor_der";
    }

    @Override
    public int getReturnSpaces() {
        return 0;
    }
}
