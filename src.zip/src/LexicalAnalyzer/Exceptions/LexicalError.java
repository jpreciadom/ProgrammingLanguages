package LexicalAnalyzer.Exceptions;

public class LexicalError extends Exception {
    public LexicalError(String message) {
        super(message);
    }
}
